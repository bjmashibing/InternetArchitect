package com.bjmashibing.shiro.moduler.system.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 * 系统功能表 前端控制器
 * </p>
 *
 * @author 孙志强
 * @since 2020-04-13
 */
@Controller
@RequestMapping("/module")
public class ModuleController {

}

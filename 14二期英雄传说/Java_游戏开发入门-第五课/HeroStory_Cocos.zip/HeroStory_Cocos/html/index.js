/**
 * 执行跳转
 * 
 * @return {void}
 */
function doJump() {
    window.location.href = "./v1.3.1/index.html?r=" + Math.random();
}

// 执行跳转
doJump();

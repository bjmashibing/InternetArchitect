// @export
module.exports = {
    "serverAddr": "39.96.62.138:12345",
};

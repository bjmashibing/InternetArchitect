package org.tinygame.herostory.mq;

/**
 * 战斗结果消息
 */
public class VictorMsg {
    /**
     * 赢家 Id
     */
    public int winnerId;

    /**
     * 输家 Id
     */
    public int loserId;
}
